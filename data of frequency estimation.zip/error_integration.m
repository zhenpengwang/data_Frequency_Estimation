load("4CHUANG.mat")
%窗文件
Win = window_BKH ;

N=65536;
f_s=8e7;

jjj=1024;
jiange = 1/jjj;
dx=-2:jiange:2;

%窗系数
%%%%%%BKH%%%%%%%
a0=0.35875;
a1=0.48829;
a2=0.14128;
a3=0.01168;

%%%%%%HN%%%%%%%
% % a0=0.5;
% % a1=0.5;
% % a2=0;
% % a3=0;

%%%%%%BK%%%%%%%
% a0=0.42;
% a1=0.5;
% a2=0.08;
% a3=0;


a4=0;
a5=0;
df=[0,1e6,-1e6,2e6,-2e6]';
%信号主瓣函数
c1=pi.*df.*N./f_s;
c2=pi.*df./f_s;
c3=pi./N;

W_up=sin(dx.*pi+c1);
W_d0=sin(dx.*c3+c2);
W_d1_a=sin(dx.*c3+c2+c3);
W_d1_m=sin(dx.*c3+c2-c3);
W_d2_a=sin(dx.*c3+c2+2*c3);
W_d2_m=sin(dx.*c3+c2-2*c3);
W_d3_a=sin(dx.*c3+c2+3*c3);
W_d3_m=sin(dx.*c3+c2-3*c3);
W_d4_a=sin(dx.*c3+c2+4*c3);
W_d4_m=sin(dx.*c3+c2-4*c3);
W_d5_a=sin(dx.*c3+c2+5*c3);
W_d5_m=sin(dx.*c3+c2-5*c3);

AW = W_up.*(a0./W_d0-a1./2.*(1./W_d1_a+1./W_d1_m)+a2./2.*(1./W_d2_a+1./W_d2_m)-a3./2.*(1./W_d3_a+1./W_d3_m)+a4./2.*(1./W_d4_a+1./W_d4_m)-a5./2.*(1./W_d5_a+1./W_d5_m));
AW(1,1)=2*AW(1,2)-AW(1,3);
AW(1,jjj+1)=(AW(1,jjj)+AW(1,jjj+2))/2;
AW(1,2*jjj+1)=(AW(1,2*jjj)+AW(1,2*jjj+2))/2;
AW(1,3*jjj+1)=(AW(1,3*jjj)+AW(1,3*jjj+2))/2;
AW(1,4*jjj+1)=2*AW(1,4*jjj)-AW(1,4*jjj-1);

AM = 0.9.*AW(1,:)+0.05.*AW(2,:)+0.05.*AW(3,:);
AL = 0.05.*AW(1,:)+0.9.*AW(3,:)+0.05.*AW(5,:);
AR = 0.05.*AW(1,:)+0.9.*AW(2,:)+0.05.*AW(4,:);

for z=1:jjj    
      CM(z) = (AM(z+jjj))/(AM(z+2*jjj));
      CL(z) = (AL(z+jjj))/(AL(z+2*jjj));
      %CL(z) = AL(z+jjj)/AL(z+3*jjj)-AL(z)/AL(z+2*jjj);
      CR(z) = (AR(z+jjj))/(AR(z+2*jjj));
end

fi = 1e6     ; % 调制信号频率
n  = 16384*4   ; % 采样点数

f_f= 5321.7   ; % 扫频增量
f_n= 3382     ; % 扫频点数
f_w = 2e6 : f_f : 2e6+f_f*f_n ;%测试频点，画图用


num_zhouqi = 147456 ;
num_data   = num_zhouqi + 65536;
num_pingjun = 16 ;

t  = 0 : 1/f_s : (num_data-1)/f_s ;   % 时域

for k = 1 : 1024
            rad_prn1(32*(k-1)+1:32*k) = 0.1*prn1(k) ;
end
rad_prn_z1 = [rad_prn1,rad_prn1,rad_prn1,rad_prn1,rad_prn1,rad_prn1,rad_prn1];
rad_prn_z  = rad_prn_z1(1:num_data);

fm=zeros(f_n+1,num_pingjun+1);
fl=zeros(f_n+1,num_pingjun+1);
fr=zeros(f_n+1,num_pingjun+1);
pj_fl=zeros(1,f_n+1);
pj_fm=zeros(1,f_n+1);
pj_fr=zeros(1,f_n+1);
ess_m=zeros(1,f_n+1);
ess_l=zeros(1,f_n+1);
ess_r=zeros(1,f_n+1);

jiancha_essl=zeros(f_n+1,num_pingjun+1);
jiancha_essr=zeros(f_n+1,num_pingjun+1);

for z = 1 : f_n+1
    
     % 主信号频率
     f = 2e6 + f_f*(z-1) ; 
     signal1 = 0.9*sin(2*pi*f*t+rad_prn_z)+0.05*sin(2*pi*(f+fi)*t)+0.05*sin(2*pi*(f-fi)*t) ;
 for j = 1 : num_pingjun+1
    
    % 设置输入信号    
     signal = signal1((j-1)*num_zhouqi/num_pingjun+1:(j-1)*num_zhouqi/num_pingjun+65536) ;
    % 输入加窗
     win_signal = signal .* (Win)' ;
    % FFT
    fft_wsignal = abs(fft(win_signal)) ;
    
    % 变量初始化
    max_a    = 0 ;
    second_a = 0 ;
    third_a  = 0 ;
    index_1  = 2 ;
    index_2  = 2 ;
    index_3  = 2 ;
    
    % 峰值查找
    for i=2:n/2
        if (fft_wsignal(i) > fft_wsignal(i-1)) && (fft_wsignal(i) > fft_wsignal(i+1))
            if fft_wsignal(i) > max_a
                third_a  = second_a      ;
                second_a = max_a         ;
                max_a    = fft_wsignal(i);
                index_3  = index_2       ;
                index_2  = index_1       ;
                index_1  = i             ;
            elseif (fft_wsignal(i) < max_a) && (fft_wsignal(i) > second_a) 
                third_a  = second_a      ;
                second_a = fft_wsignal(i);
                index_3  = index_2       ;
                index_2  = i             ;
            elseif (fft_wsignal(i) < second_a) && (fft_wsignal(i) > third_a)
                third_a  = fft_wsignal(i);
                index_3  = i             ;
            end
        end
    end

    % 确定三频率索引点
       index_m = index_1 ;
    if index_2 < index_3 
       index_l = index_2 ;
       index_r = index_3 ;
    else
       index_l = index_3 ;
       index_r = index_2 ;
    end
    
    % 频谱矫正算法
    if fft_wsignal(index_m-1) > fft_wsignal(index_m+1)
        AM_1 = fft_wsignal(index_m-2);
        AM_2 = fft_wsignal(index_m-1);
        AM_3 = fft_wsignal(index_m  );
        AM_4 = fft_wsignal(index_m+1);
        index_m = index_m -1 ;
    else
        AM_1 = fft_wsignal(index_m-1);
        AM_2 = fft_wsignal(index_m);
        AM_3 = fft_wsignal(index_m+1);
        AM_4 = fft_wsignal(index_m+2);
    end
    
    if fft_wsignal(index_l-1) > fft_wsignal(index_l+1)
        AL_1 = fft_wsignal(index_l-2);
        AL_2 = fft_wsignal(index_l-1);
        AL_3 = fft_wsignal(index_l  );
        AL_4 = fft_wsignal(index_l+1);
        index_l = index_l -1 ;
    else
        AL_1 = fft_wsignal(index_l-1);
        AL_2 = fft_wsignal(index_l  );
        AL_3 = fft_wsignal(index_l+1);
        AL_4 = fft_wsignal(index_l+2);
    end
    
    if fft_wsignal(index_r-1) > fft_wsignal(index_r+1)
        AR_1 = fft_wsignal(index_r-2);
        AR_2 = fft_wsignal(index_r-1);
        AR_3 = fft_wsignal(index_r  );
        AR_4 = fft_wsignal(index_r+1);
        index_r = index_r -1 ;
    else
        AR_1 = fft_wsignal(index_r-1);
        AR_2 = fft_wsignal(index_r  );
        AR_3 = fft_wsignal(index_r+1);
        AR_4 = fft_wsignal(index_r+2);
    end
    
    M_bizhi=(AM_2)/(AM_3);
    L_bizhi=(AL_2)/(AL_3);
    R_bizhi=(AR_2)/(AR_3);   

    for y=1:jjj-1
            if  M_bizhi <= CM(1) 
               dm=0;
            elseif M_bizhi > CM(jjj)
               dm=jjj-0.5;
            elseif (CM(y+1)> M_bizhi)&& (M_bizhi >= CM(y))
               dm=y-0.5;
            end
            
            if (CL(y+1)> L_bizhi)&& (L_bizhi >= CL(y))
                   dl = y-0.5 ;
            elseif L_bizhi > CL(jjj)
                   dl=jjj-0.5;
            elseif L_bizhi <= CL(1)
                   dl=0;       
            end
            
            if (CR(y+1)> R_bizhi)&& (R_bizhi >= CR(y))
                   dr = y-0.5 ;
            elseif R_bizhi > CR(jjj)
                   dr=jjj-0.5;
            elseif R_bizhi <= CR(1)
                   dr=0;
            end        
    end 
    
    fm(z,j) = (index_m-(dm)*jiange)*f_s/n;
    fl(z,j) = (index_l-(dl)*jiange)*f_s/n;
    fr(z,j) = (index_r-(dr)*jiange)*f_s/n;

    
    jiancha_essl(z,j)=fl(z,j)-f+1e6;
    jiancha_essr(z,j)=fr(z,j)-f-1e6;
 end  
 
 
 pj_fl(z)=mean(fl(z,:));
 pj_fr(z)=mean(fr(z,:));
 pj_fm(z)=mean(fm(z,:));
 
 % 误差计算
 ess_m(z) = f       - pj_fm(z) ;
 ess_l(z) = f - 1e6 - pj_fl(z) ;
 ess_r(z) = f + 1e6 - pj_fr(z) ; 
 
end



figure(1)
subplot(1,3,1);
plot(f_w-1e6,ess_l);
xlabel('左频频率（Hz）');
ylabel('捕获误差（Hz）');
subplot(1,3,2);
plot(f_w,ess_m);
xlabel('中频频率（Hz）');
ylabel('捕获误差（Hz）');
subplot(1,3,3);
plot(f_w+1e6,ess_r);
xlabel('右频频率（Hz）');
ylabel('捕获误差（Hz）');

fm_BKH = pj_fm;
fr_BKH = pj_fr;
fl_BKH = pj_fl;
